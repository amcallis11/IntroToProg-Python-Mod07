# ------------------------------------------------- #
# Title: <Assignment07>
# Description: <Picking and Error handling>
# ChangeLog: (Who, When, What)
# <Example Dev,01/01/2030,Created Script>
# ------------------------------------------------- #

# Import Modules
import pickle

# Initialize Variables
file = "Client_fees.dat"  # File name for storing client data
choice = None  # User menu choice
dicRow = {}  # Dictionary row
lstTable = []  # List of dictionary rows

# Get user data for dictionary
while True:
    client = str(input("Who is the client? ")).strip()
    media = str(input("What is the media type? ")).strip()

# Try-Except block to check the user enters the fee as a floating point number
    while True:  # Loop around until they enter the correct data type
        try:
            fee = float(input("What is the fee ($Total Dollars)? "))
            break
        except ValueError:
            print("Oops. Please enter a valid fee as a number.")

# Add user entered data as dictionary
    dicRow = {"ClientName": client, "MediaType": media, "Fee": fee}  # Create dictionary row for client data
    lstTable.append(dicRow)  # Append dictionary row to the list

# To add multiple rows of data, ask user if they want to continue or finish entering data
    choice = input("Do you want to enter data for another client? (yes/no): ").lower().strip()  # Prompt user to continue entering data
    if choice != "yes":
        break  # If user does not want to enter more data, exit the loop

# Open file and write data to binary file
objFile = open(file, "wb")  # Open the file in write mode
pickle.dump(lstTable, objFile)  # Write the list of dictionary rows to the file using pickle
objFile.close()

# Open file and read data form binary file
objFile = open(file, "rb")  # Open the file in read mode
objFileData = pickle.load(objFile)  # Open the file in read mode
objFile.close()

print(objFileData)  # Print the data read from the file
